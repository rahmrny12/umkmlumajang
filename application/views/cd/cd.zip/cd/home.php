<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title>UMKM LUMAJANG</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta content="" name="keywords">
	<meta content="" name="description">

	<!-- Favicon -->
	<link href="<?= base_url(); ?>assets/home/img2/favicon.ico" rel="icon">

	<!-- Google Web Fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Teko:wght@400;500;600&display=swap" rel="stylesheet">

	<!-- Icon Font Stylesheet -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

	<!-- Libraries Stylesheet -->
	<link href="<?= base_url(); ?>assets/home/lib2/animate/animate.min.css" rel="stylesheet">
	<link href="<?= base_url(); ?>assets/home/lib2/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
	<link href="<?= base_url(); ?>assets/home/lib2/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

	<!-- Customized Bootstrap Stylesheet -->
	<link href="<?= base_url(); ?>assets/home/css2/bootstrap.min.css" rel="stylesheet">

	<!-- Template Stylesheet -->
	<link href="<?= base_url(); ?>assets/home/css2/style.css" rel="stylesheet">
</head>

<body>

	<!-- Navbar Start -->
	<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top py-lg-0 px-lg-4 wow fadeIn" data-wow-delay="0.1s">
		<a href="index.html" class="navbar-brand ms-4 ms-lg-0">
			<h2 class="text-dark m-0"><img class="me-6">UMKMLUMAJANG</h2>
		</a>
		<button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarCollapse">
			<div class="navbar-nav ms-auto p-4 p-lg-0">
				<a href="index.php" class="nav-item nav-link ">Home</a>
				<a href="berita.php" class="nav-item nav-link">berita</a>
				<a href="#" class="nav-item nav-link">Pengumuman</a>
				<a href="kontak.php" class="nav-item nav-link">statistik</a>
				<a href="kontak.php" class="nav-item nav-link">open data</a>
			</div>
		</div>
		<a href="<?= base_url(); ?>auth/login" class="btn btn-outline-info py-2 px-3">Login</a>
	</nav>
	<!-- Navbar End -->

	<!-- Carousel Start -->
	<div class="container-fluid p-0 pb-0 wow fadeIn">
		<div class="owl-carousel header-carousel position-relative">
			<div>
				<img class="img-fluid" src="<?= base_url(); ?>assets/home/img2/a.jpg" alt="">
				<div class="owl-carousel-inner">
					<div class="container">
						<div class="row ">
							<div class="col-12 col-lg-8">
								<h1 class="display-1 text-white animated slideInDown">UMKM LUMAJANG</h1>
								<p class="fs-4 fw-medium text-white mb-1 pb-3">Portal Informasi Terpadu <br> Dinas Koperasi Usaha Kecil dan Menengah
									<br>Kota Lumajang, Jawa Timur.
								</p>
								<a href="<?= base_url(); ?>auth/registration" class="btn btn-info py-2 px-5 animated slideInLeft" style="border-radius: 10px;">Ayo, Daftar Sekarang</a> &nbsp;
								<a href="<?= base_url(); ?>user/lapak" target="_blank" class="btn btn-light py-2 px-5 animated slideInLeft" style="border-radius: 10px;">Lapak UMKM</a> &nbsp;
								<a href="https://lumajangvirtualtour.my.id/" target="_blank" class="btn btn-warning py-2 px-5 animated slideInLeft" style="border-radius: 10px;">Virtual Tour</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<img class="img-fluid owl-carousel header-carousel position-relative" src="<?= base_url(); ?>assets/home/img2/b.jpg" alt="">
	</div>
	<!-- Carousel End -->


	<!-- Service Start -->
	<div class="container-fluid py-5 bg-info">
		<div class="container">
			<div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
				<h1 class="display-5 mb-4">Pengumuman</h1>
			</div>
			<div class="row g-4">
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-1.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-5.png" alt="Icon">
							<h3 class="mb-3">Architecture</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-2.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-6.png" alt="Icon">
							<h3 class="mb-3">3D Animation</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-3.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-7.png" alt="Icon">
							<h3 class="mb-3">House Planning</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-4.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-8.png" alt="Icon">
							<h3 class="mb-3">Interior Design</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img/service-5.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-9.png" alt="Icon">
							<h3 class="mb-3">Renovation</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-6.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-10.png" alt="Icon">
							<h3 class="mb-3">Construction</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Service End -->
	<br>
	<br>
	<br>
	<div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
		<h1 class="display-5 mb-4">Lokasi Pusat Lumajang</h1>
	</div>
	<div class="d-flex justify-content-center">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1911.2391238751159!2d113.22493169957556!3d-8.135474967590872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd667c815555555%3A0x5aec0923509a05f3!2sAlun%20-%20Alun%20Lumajang!5e0!3m2!1sid!2sid!4v1701303577330!5m2!1sid!2sid" class="col-md-11" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
	<br>
	<br>
	<br>
	<!-- Service Start -->
	<div class="container-fluid py-5 bg-warning">
		<div class="container">
			<div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
				<h1 class="display-5 mb-4">Fasilitas dan Bantuan</h1>
			</div>
			<div class="row g-4">
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-1.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-5.png" alt="Icon">
							<h3 class="mb-3">Architecture</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-2.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-6.png" alt="Icon">
							<h3 class="mb-3">3D Animation</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-3.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-7.png" alt="Icon">
							<h3 class="mb-3">House Planning</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-4.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-8.png" alt="Icon">
							<h3 class="mb-3">Interior Design</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-5.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-9.png" alt="Icon">
							<h3 class="mb-3">Renovation</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
					<div class="service-item d-flex position-relative text-center h-100">
						<img class="bg-img" src="<?= base_url(); ?>assets/home/img2/service-6.jpg" alt="">
						<div class="service-text p-5">
							<img class="mb-4" src="<?= base_url(); ?>assets/home/img2/icons/icon-10.png" alt="Icon">
							<h3 class="mb-3">Construction</h3>
							<p class="mb-4">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet.</p>
							<a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Service End -->


	<!-- Footer Start -->
	<div class="container-fluid bg-dark text-body footer mt-5 pt-5 px-0 wow fadeIn" data-wow-delay="0.1s">
		<div class="container py-5">
			<div class="row g-5">
				<div class="col-lg-2 col-md-6">
				</div>
				<div class="col-lg-3 col-md-6">
					<img class="img" src="<?= base_url(); ?>assets/home/img2/h.png" alt="">
				</div>
				<div class="col-lg-3 col-md-6">
					<h3 class="text-light mb-4">Kontak</h3>
					<p class="text-light">Jln. Letkol S. Wardoyo No. 43-45 Lumajang.</p>
					<p class="text-light">Telp.0334-881606</p>
					<p class="text-light">diskopindag@lumajangkab.go.id</p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3 class="text-light mb-4">Jam Pelayanan</h3>
					<p class="text-light">Senin : 08.00 – 14.00 <br>
						Selasa : 08.00 – 14.00 <br>
						Rabu : 08.00 – 14.00 <br>
						Kamis : 08.00 – 14.00 <br>
						Jumat : 08.00 – 10.00</p>
				</div>
			</div>
		</div>
		<div class="container-fluid copyright">
			<div class="container">
				<div class="row">
					<div class="text-center text-md-start">
						&copy; <a href="#">Powered By Dinas Komunikasi dan Informatika Kabupaten Lumajang</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer End -->


	<!-- Back to Top -->
	<!-- <div class="card col-4"> -->
	<!-- <div class="card-body"> -->
	<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
	<!-- </div> -->
	<!-- </div> -->


	<!-- JavaScript Libraries -->
	<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/wow/wow.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/easing/easing.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/waypoints/waypoints.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/counterup/counterup.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/owlcarousel/owl.carousel.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/tempusdominus/js/moment.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/tempusdominus/js/moment-timezone.min.js"></script>
	<script src="<?= base_url(); ?>assets/home/lib2/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

	<!-- Template Javascript -->
	<script src="<?= base_url(); ?>assets/home/js2/main.js"></script>
</body>

</html>
