</main>

<!-- All Script JS Plugins here  -->
<script src="<?= base_url(); ?>assets/suruci/js/vendor/popper.js" defer="defer"></script>
<script src="<?= base_url(); ?>assets/suruci/js/vendor/bootstrap.min.js" defer="defer"></script>
<script src="<?= base_url(); ?>assets/suruci/js/plugins/swiper-bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/suruci/js/plugins/glightbox.min.js"></script>

<!-- Customscript js -->
<script src="<?= base_url(); ?>assets/suruci/js/script.js"></script>

</body>
</html>